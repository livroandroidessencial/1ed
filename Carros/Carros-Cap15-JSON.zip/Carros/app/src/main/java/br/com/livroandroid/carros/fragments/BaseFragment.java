package br.com.livroandroid.carros.fragments;

public class BaseFragment extends livroandroid.lib.fragment.BaseFragment {
}
